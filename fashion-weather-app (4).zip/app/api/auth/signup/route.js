import { NextResponse } from "next/server"
import { findUserByPhone, addUser } from "@/lib/users-db"

export async function POST(request) {
  try {
    const { phoneNumber, password, name } = await request.json()

    console.log("[v0] 회원가입 시도:", phoneNumber, name)

    const existingUser = await findUserByPhone(phoneNumber)
    if (existingUser) {
      console.log("[v0] 회원가입 실패: 이미 존재하는 전화번호")
      return NextResponse.json({ message: "이미 등록된 전화번호입니다" }, { status: 400 })
    }

    const newUser = await addUser(phoneNumber, password, name)
    console.log("[v0] 회원가입 성공:", newUser.name)

    return NextResponse.json({
      message: "회원가입이 완료되었습니다",
      user: {
        phoneNumber: newUser.phoneNumber,
        name: newUser.name,
      },
    })
  } catch (error) {
    console.error("[v0] 회원가입 오류:", error)
    return NextResponse.json({ message: "서버 오류가 발생했습니다" }, { status: 500 })
  }
}
