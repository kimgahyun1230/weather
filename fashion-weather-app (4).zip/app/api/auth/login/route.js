import { NextResponse } from "next/server"
import { findUser } from "@/lib/users-db"

export async function POST(request) {
  try {
    const { phoneNumber, password } = await request.json()

    console.log("[v0] 로그인 시도:", phoneNumber)

    const user = await findUser(phoneNumber, password)

    if (!user) {
      console.log("[v0] 로그인 실패: 사용자를 찾을 수 없음")
      return NextResponse.json({ message: "전화번호 또는 비밀번호가 일치하지 않습니다" }, { status: 401 })
    }

    console.log("[v0] 로그인 성공:", user.name)

    // JWT 토큰 생성 (실제로는 jwt 라이브러리를 사용해야 합니다)
    const token = Buffer.from(
      JSON.stringify({
        phoneNumber: user.phoneNumber,
        name: user.name,
        timestamp: Date.now(),
      }),
    ).toString("base64")

    return NextResponse.json({
      token,
      user: {
        phoneNumber: user.phoneNumber,
        name: user.name,
      },
    })
  } catch (error) {
    console.error("[v0] 로그인 오류:", error)
    return NextResponse.json({ message: "서버 오류가 발생했습니다" }, { status: 500 })
  }
}
