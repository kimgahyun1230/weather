import { S3Client, ListObjectsV2Command } from "@aws-sdk/client-s3"
import { NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// ========================================
// 🔐 JWT 인증 확인
// ========================================
// 로그인한 사용자만 API를 사용할 수 있습니다
function checkAuth(request) {
  const authHeader = request.headers.get("authorization")
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { authenticated: false }
  }

  const token = authHeader.substring(7)
  const decoded = verifyToken(token)

  if (!decoded) {
    return { authenticated: false }
  }

  return { authenticated: true, user: decoded }
}

// ========================================
// 📦 S3 클라이언트 설정
// ========================================
const s3Client = new S3Client({
  region: process.env.AWS_REGION || "ap-northeast-2", // 서울 리전
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
})

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME || "fashionweather" // 기본값으로 fashionweather 추가

// ========================================
// 🎯 GET 요청 핸들러
// ========================================
export async function GET(request) {
  // JWT 인증 확인
  const auth = checkAuth(request)
  if (!auth.authenticated) {
    return NextResponse.json({ error: "인증이 필요합니다" }, { status: 401 })
  }

  // URL에서 스타일 타입 가져오기
  const { searchParams } = new URL(request.url)
  const styleType = searchParams.get("style") || "casual" // casual, formal, street, random
  const count = Number.parseInt(searchParams.get("count") || "9")

  console.log("[v0] S3에서 이미지 가져오기:", { styleType, count })

  try {
    // S3 버킷에서 해당 스타일 폴더의 이미지 목록 가져오기
    const command = new ListObjectsV2Command({
      Bucket: BUCKET_NAME,
      Prefix: `${styleType}/`, // 예: casual/, formal/, street/, random/
    })

    const response = await s3Client.send(command)

    // 이미지 파일만 필터링 (jpg, jpeg, png, webp)
    const imageFiles = (response.Contents || [])
      .filter((item) => {
        const key = item.Key.toLowerCase()
        return key.endsWith(".jpg") || key.endsWith(".jpeg") || key.endsWith(".png") || key.endsWith(".webp")
      })
      .map((item) => ({
        key: item.Key,
        url: `https://${BUCKET_NAME}.s3.${process.env.AWS_REGION || "ap-northeast-2"}.amazonaws.com/${item.Key}`,
      }))

    console.log("[v0] S3에서 찾은 이미지 개수:", imageFiles.length)

    // 랜덤으로 섞기
    const shuffled = imageFiles.sort(() => Math.random() - 0.5)

    // 요청한 개수만큼 선택
    const selected = shuffled.slice(0, count)

    return NextResponse.json(selected)
  } catch (error) {
    console.error("[v0] S3 이미지 가져오기 오류:", error)
    return NextResponse.json(
      { error: "S3에서 이미지를 가져오는데 실패했습니다", details: error.message },
      { status: 500 },
    )
  }
}
