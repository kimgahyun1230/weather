"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"

// ========================================
// 📊 기온별 옷차림 키워드 매핑
// ========================================
// 사용자가 제공한 기온별 옷차림표를 그대로 사용합니다
const getClothingKeywords = (temperature) => {
  if (temperature >= 28) {
    // 28℃ 이상
    return "sleeveless tank top shorts dress summer"
  } else if (temperature >= 23) {
    // 27~23℃
    return "t-shirt light shirt shorts cotton pants"
  } else if (temperature >= 20) {
    // 22~20℃
    return "light cardigan long sleeve cotton pants jeans"
  } else if (temperature >= 17) {
    // 19~17℃
    return "light knit sweatshirt cardigan jeans"
  } else if (temperature >= 12) {
    // 16~12℃
    return "jacket cardigan field jacket stockings jeans"
  } else if (temperature >= 9) {
    // 11~9℃
    return "jacket trench coat knit jeans stockings"
  } else if (temperature >= 5) {
    // 8~5℃
    return "coat leather jacket heattech knit leggings"
  } else {
    // 4℃ 이하
    return "padding thick coat scarf fleece"
  }
}

// ========================================
// 🔍 Unsplash 검색어 생성 함수
// ========================================
const generateSearchQuery = (styleType, temperature) => {
  // 1단계: 스타일 키워드
  const styleKeyword = styleType === "random" ? "feminine" : styleType

  // 2단계: 기온별 옷차림 키워드
  const clothingKeywords = getClothingKeywords(temperature)

  // 3단계: 검색어 조합 - 20대 여성, Pinterest 스타일 강조
  const searchQuery = `${styleKeyword} 20s young korean woman fashion ${clothingKeywords} pinterest aesthetic street style lookbook`

  console.log("[v0] 생성된 검색어:", searchQuery)
  return searchQuery
}

const HeartIcon = ({ className, filled }) => (
  <svg className={className} fill={filled ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
    />
  </svg>
)

const RefreshIcon = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
    />
  </svg>
)

export function FashionItemsGallery({ selectedStyle, weather }) {
  // ========================================
  // 📦 상태 관리 (State)
  // ========================================
  const [images, setImages] = useState([]) // 표시할 이미지 9장
  const [loading, setLoading] = useState(false) // 로딩 중인지 확인
  const [likedImages, setLikedImages] = useState(new Set()) // 좋아요 누른 이미지들

  // ========================================
  // 🎯 Unsplash API 호출 함수
  // ========================================
  const fetchFashionImages = async () => {
    setLoading(true)
    console.log("[v0] S3 API 호출 시작")

    try {
      const token = localStorage.getItem("jwt_token")
      const response = await fetch(`/api/s3-images?style=${selectedStyle}&count=9`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        throw new Error("S3 이미지 가져오기 실패")
      }

      const s3Images = await response.json()
      console.log("[v0] S3에서 받은 이미지 개수:", s3Images.length)

      const imageUrls = s3Images.map((img) => img.url)
      setImages(imageUrls)
      console.log("[v0] 최종 선택된 이미지:", imageUrls.length, "개")
    } catch (error) {
      console.error("[v0] S3 API 오류:", error)

      // 오류 발생 시 placeholder 이미지 사용
      const fallbackImages = Array.from(
        { length: 9 },
        (_, i) => `/placeholder.svg?height=400&width=300&query=${encodeURIComponent(`fashion ${i + 1}`)}`,
      )
      setImages(fallbackImages)
    } finally {
      setLoading(false)
    }
  }

  // ========================================
  // 🔄 버튼 클릭 시 이미지 로드
  // ========================================
  // selectedStyle이나 weather가 바뀔 때마다 실행
  useEffect(() => {
    console.log("[v0] 스타일 또는 날씨 변경 감지:", {
      style: selectedStyle,
      temperature: weather?.temperature,
    })

    if (selectedStyle && weather?.temperature !== undefined) {
      fetchFashionImages()
    }
  }, [selectedStyle, weather])

  // ========================================
  // ❤️ 좋아요 토글 함수
  // ========================================
  const toggleLike = (imageIndex) => {
    setLikedImages((prev) => {
      const newLiked = new Set(prev)
      if (newLiked.has(imageIndex)) {
        newLiked.delete(imageIndex)
      } else {
        newLiked.add(imageIndex)
      }
      return newLiked
    })
  }

  const handleRefresh = () => {
    console.log("[v0] 다른 추천 받기 버튼 클릭")
    fetchFashionImages()
  }

  // ========================================
  // 🎨 UI 렌더링
  // ========================================

  // 스타일 이름 한글 변환
  const getStyleName = (styleType) => {
    const names = {
      casual: "캐주얼",
      formal: "포멀",
      street: "스트릿",
      random: "랜덤",
    }
    return names[styleType] || styleType
  }

  // 온도별 설명
  const getTemperatureDescription = (temp) => {
    if (temp >= 28) return "민소매, 반팔, 반바지 추천"
    if (temp >= 23) return "반팔, 얇은 셔츠, 면바지 추천"
    if (temp >= 20) return "얇은 가디건, 긴팔, 청바지 추천"
    if (temp >= 17) return "얇은 니트, 맨투맨, 가디건 추천"
    if (temp >= 12) return "자켓, 가디건, 야상 추천"
    if (temp >= 9) return "자켓, 트렌치코트, 니트 추천"
    if (temp >= 5) return "코트, 가죽자켓, 히트텍 추천"
    return "패딩, 두꺼운 코트, 목도리 추천"
  }

  // 로딩 중 화면
  if (loading) {
    return (
      <div className="text-center space-y-3 py-8">
        <div className="text-3xl animate-bounce">👗</div>
        <p className="text-base font-medium">S3에서 패션 이미지를 찾고 있어요...</p>
        <div className="w-full bg-secondary rounded-full h-2 max-w-xs mx-auto">
          <div className="bg-primary h-2 rounded-full animate-pulse w-3/4"></div>
        </div>
      </div>
    )
  }

  // 이미지가 없을 때
  if (images.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>스타일을 선택해주세요</p>
      </div>
    )
  }

  // 메인 화면
  return (
    <div className="space-y-4">
      {/* 제목 */}
      <div className="text-center space-y-1">
        <h2 className="text-lg font-semibold">{getStyleName(selectedStyle)} 스타일</h2>
        <p className="text-xs text-muted-foreground">
          {weather?.temperature}°C - {getTemperatureDescription(weather?.temperature)}
        </p>
      </div>

      {/* 이미지 그리드 (3x3) */}
      <div className="grid grid-cols-3 gap-2">
        {images.map((image, index) => (
          <div key={index} className="relative group">
            <div className="relative overflow-hidden rounded-lg bg-gray-100 aspect-square">
              <img
                src={image || "/placeholder.svg"}
                alt={`${getStyleName(selectedStyle)} 스타일 ${index + 1}`}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
                onError={(e) => {
                  e.target.src = `/placeholder.svg?height=200&width=200`
                }}
              />

              <button
                onClick={() => toggleLike(index)}
                className="absolute top-1 right-1 p-1.5 bg-white/80 backdrop-blur-sm rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-white hover:scale-110"
              >
                <HeartIcon
                  className={`w-3 h-3 ${likedImages.has(index) ? "text-red-500" : "text-gray-600"}`}
                  filled={likedImages.has(index)}
                />
              </button>

              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
            </div>
          </div>
        ))}
      </div>

      <div className="text-center pt-2">
        <Button onClick={handleRefresh} variant="outline" size="sm" className="gap-2 bg-transparent">
          <RefreshIcon className="w-3 h-3" />
          다른 추천 받기
        </Button>
      </div>

      {/* 안내 문구 */}
      <div className="text-center">
        <p className="text-xs text-muted-foreground">S3 버킷에서 가져온 패션 스타일</p>
      </div>
    </div>
  )
}
